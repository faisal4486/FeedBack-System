const Router = require('express').Router;
const router = Router();

module.exports = router;