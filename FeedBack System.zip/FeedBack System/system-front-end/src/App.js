import React from "react";
import MiniDrawer from "./Admin/AdminMain";
import StudentMain from "./Student/StudentMain";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Redirect,
} from "react-router-dom";
import LogIn from "./Login";
import SignUp from "./SignUp";
import AdminLogIn from "./Admin/AdminLogin";
import { AuthContext } from "./Auth/Auth-context";
import { useAuth } from "./Auth/auth";

// const studentId = 1520181142;

function App() {
  const { token, login, logout, userId } = useAuth();
  console.log(token, login, logout, userId);

  let routes;

  if (token) {
    routes = (
      <Switch>
        <Route path="/student/evaluation">
          <StudentMain componentName="evaluation" userId={userId} />
        </Route>
        <Route path="/student/feedback">
          <StudentMain componentName="feedback" />
        </Route>
        <Redirect to="/student/evaluation" />
      </Switch>
    );
  } else {
    routes = (
      <Switch>
        <Route path="/login">
          <LogIn />
        </Route>
        <Route path="/admin/login">
          <AdminLogIn />
        </Route>
        <Route path="/SignUp">
          <SignUp />
        </Route>
        <Route path="/admin" exact>
          <MiniDrawer componentName="Home" />
        </Route>
        <Route path="/admin/department">
          <MiniDrawer componentName="Department" />
        </Route>
        <Route path="/admin/Report">
          <MiniDrawer componentName="Report" />
        </Route>
        <Route path="/admin/Reset">
          <MiniDrawer componentName="Reset" />
        </Route>
        <Redirect to="/login" />
      </Switch>
    );
  }

  return (
    <div className="App">
      <AuthContext.Provider
        value={{
          isLoggedIn: !!token,
          token: token,
          userId: userId,
          login: login,
          logout: logout,
        }}>
        <Router>{routes}</Router>
      </AuthContext.Provider>
    </div>
  );
}

export default App;
