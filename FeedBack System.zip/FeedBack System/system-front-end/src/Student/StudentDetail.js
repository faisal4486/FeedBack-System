import React from "react";
import Avatar from "@material-ui/core/Avatar";
import { makeStyles } from "@material-ui/core/styles";
import Faisal from "../Images/Faisal.jpg";
import Typography from "@material-ui/core/Typography";
import Grid from "@material-ui/core/Grid";
// import Button from "@material-ui/core/Button";

const useStyle = makeStyles((theme) => ({
  root: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },
  large: {
    width: theme.spacing(10),
    height: theme.spacing(10),
    justifyContent: "center",
  },
}));
const details = {
  name: "Faisal Shaikh",
  semester: 6,
  id: 1520181142,
  rollno: 40,
  course: "BSc-IT",
  division: "A",
  batch: "2020-2021",
};

function StudentDetail() {
  const classes = useStyle();
  var utc = new Date().toJSON().slice(0, 10).replace(/-/g, "/");

  return (
    <div className={classes.root}>
      <Avatar alt="F" src={Faisal} className={classes.large} boxShadow={3} />
      {/* <Divider /> */}
      <div style={{ padding: "0 5px 0 12px" }}>
        <Grid container spacing={1}>
          <Grid item xs={6}>
            <Typography
              style={{
                paddingTop: "10px",
              }}
              variant="h6">
              Name
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{
                paddingTop: "10px",
              }}
              variant="h6">
              {details.name}
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{
                paddingTop: "10px",
              }}>
              Semester
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{
                paddingTop: "10px",
              }}>
              {details.semester}
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{
                paddingTop: "10px",
              }}>
              ID
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{
                paddingTop: "10px",
              }}>
              {details.id}
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{
                paddingTop: "10px",
              }}>
              Roll No
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{
                paddingTop: "10px",
              }}>
              {details.rollno}
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{
                paddingTop: "10px",
              }}>
              Course
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{
                paddingTop: "10px",
              }}>
              {details.course}
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{
                paddingTop: "10px",
              }}>
              Divison
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{
                paddingTop: "10px",
              }}>
              {details.division}
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{
                paddingTop: "10px",
              }}>
              Date
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{
                paddingTop: "10px",
              }}>
              {utc}
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{
                paddingTop: "10px",
              }}>
              Batch
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{
                paddingTop: "10px",
              }}>
              {details.batch}
            </Typography>
          </Grid>
        </Grid>
      </div>
      {/* <Button variant="contained" color="primary" style={{ marginTop: "20px" }}>
        LogOut
      </Button> */}
    </div>
  );
}

export default StudentDetail;
