import React, {useState,useEffect} from "react";
import { makeStyles, createStyles } from "@material-ui/core/styles";
import FacultyForm from "./FacultyForm";
import SubjectSelect from "./SubjectSelect";
import Paper from "@material-ui/core/Paper";
import Typography from "@material-ui/core/Typography";
import Button from "@material-ui/core/Button";
import axios from "axios";

const useStyles = makeStyles((theme) =>
  createStyles({
    root: {
      width: "100%",
    },
    button: {
      marginTop: theme.spacing(1),
      marginRight: theme.spacing(1),
    },
    actionsContainer: {
      marginBottom: theme.spacing(2),
    },
    resetContainer: {
      padding: theme.spacing(3),
    },
  })
);

function getSteps() {
  return [
    "Knowledge of Subject",
    "Ability to Explain (oral)",
    "Use of examples",
    "Teaching Material",
    "Use of training aids",
    "Opportunity to raise questions & discussion",
    "Regularity in engaging Classes",
    "Impartiality",
    "Attitude towards student's difficulty",
    "Overall impression of Teaching",
    "Remark"
  ];
}

function FacultyMain(props) {
  const classes = useStyles();
  const points = {
    qts1: "",
    qts2: "",
    qts3: "",
    qts4: "",
    qts5: "",
    qts6: "",
    qts7: "",
    qts8: "",
    qts9: "",
    qts10: "",
  }

  const [activeStep, setActiveStep] = useState(0);
  const [validate, setValidate] = useState(true);
  const [feedback, setFeedback] = useState(points);
  const [subject, setSubject] = useState("");
  const [teacher, setteacher] = useState("");
  const [teacherId,setTeacherId] = useState(null);
  const [remark,setRemark]=useState("");
  const [getTeacher, setGetTeacher] = useState([]);

  const steps = getSteps();

  const studentData = JSON.parse(localStorage.getItem("studentData"));

  useEffect(()=>{
    axios.get(`faculty_id/${teacher}`)
    .then(result=>{
         setTeacherId(result.data[0].faculty_id);
         console.log(result)
    }).catch(err=>{
        console.log(err);
    }) 
  },[teacher])

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
    setValidate(true);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleSubmit = (e) => {
    axios.post('student_feedback',{
        student_course:studentData.course,
        student_id: studentData.student_id,
        student_first_name: studentData.firstname,
        student_last_name: studentData.lastname,
        student_batch: studentData.batch,
        student_sem: studentData.semester ,
        student_div: studentData.div ,
        subject_name: subject,
        faculty_name: teacher,
        faculty_id : teacherId,
        student_feedback: feedback,
        remark:remark,
    })
    .then(result=>{
        console.log(result)
    })
    .catch(err=>{
        console.log(err)
    })

    setActiveStep(0);
    setFeedback(points);
    e.preventDefault();

  };

  const handleReset = (e) =>{
    setActiveStep(0);
    setFeedback(points);
    e.preventDefault();
  }

  const handleChange = (input) => (e) => {
    setFeedback((prev) => {
      return {
        ...prev,
        [input]: e.target.value,
      };
    });
    setValidate(false);
  };
 

  const handleSubject = (event) => {
    setSubject(event.target.value);
  };

  const handleFaculty = (event) => {
    console.log(event.target.value)
    setteacher(event.target.value);
   
  };

  const handleFacultyClick = (item) => {
    setGetTeacher(item);
  };

  const handleRemarkChange = (e) =>{
    setRemark(e.target.value);
    setValidate(false);
  }
  return (
    <div>
      <SubjectSelect
        handleSubject={handleSubject}
        handleFaculty={handleFaculty}
        handleFacultyClick={handleFacultyClick}
        subject={subject}
        teacher={teacher}
        getTeacher={getTeacher}
      />
      <FacultyForm
        activeStep={activeStep}
        feedback={feedback}
        steps={steps}
        handleNext={handleNext}
        handleBack={handleBack}
        handleChange={handleChange}
        handleRemarkChange={handleRemarkChange}
        remark={remark}
        validate={validate}
      />    
      {activeStep === steps.length && (
        <Paper square elevation={0} className={classes.resetContainer}>
          <Typography>All steps completed - you&apos;re finished</Typography>
          <Button
            onClick={handleSubmit}
            variant="contained"
            color="primary"
            className={classes.button}>
            Submit
          </Button>
          <Button
            onClick={handleReset}
            variant="contained"
            color="primary"
            className={classes.button}>
            Reset
          </Button>
        </Paper>
      )}
    </div>
  );
}
export default FacultyMain;
