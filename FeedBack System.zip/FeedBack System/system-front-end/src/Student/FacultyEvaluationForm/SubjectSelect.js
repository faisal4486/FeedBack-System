import React,{useEffect} from "react";
import { makeStyles } from "@material-ui/core/styles";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import FormHelperText from "@material-ui/core/FormHelperText";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import axios from 'axios';

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "spaceBetween",
  },
  formControl: {
    margin: "0 5%",
    minWidth: 120,
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
}));

function SubjectSelect(props) {
  const classes = useStyles();
  
  const [facultyData,setFacultyData]= React.useState([]);

  const studentData = JSON.parse(localStorage.getItem("studentData"));
 
     useEffect(()=>{
       axios
       .get(`subjects/${studentData.course}/${studentData.semester}/${studentData.div}`)
       .then(res=>{
           setFacultyData(res.data[0].subjects);
       })
       .catch(err=>{
           console.log(err);
       })
     },[])

  return (
    <div className={classes.root}>
      <FormControl className={classes.formControl}>
        <InputLabel id="demo-simple-select-label">Subject</InputLabel>
        <Select
          labelId="demo-simple-select-label"
          id="demo-simple-select"
          value={props.subject}
          onChange={props.handleSubject}>
          {facultyData.map((value) => {
            return (
              <MenuItem
                value={value.subjectName}
                onClick={() => {
                  props.handleFacultyClick(value.faculty);
                }}>
                {value.subjectName}
              </MenuItem>
            );
          })}
        </Select>
      </FormControl>
      <FormControl className={classes.formControl}>
        <InputLabel id="demo-simple-select-helper-label">Faculty</InputLabel>
        <Select
          labelId="demo-simple-select-helper-label"
          id="demo-simple-select-helper"
          value={props.teacher}
          onChange={props.handleFaculty}>
          {props.getTeacher.map((item) => {
            return <MenuItem value={item}>{item}</MenuItem>;
          })}
        </Select>
        <FormHelperText>
          Select the Faculty for Particular Subject
        </FormHelperText>
      </FormControl>
    </div>
  );
}
export default SubjectSelect;
