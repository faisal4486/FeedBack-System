const steps = [
  {
      name: "qts1",
      options: [
        "Exceedingly knowledgeable",
        "Adequately knowledgeable",
        "Inadequately informed",
        "Poorly informed",
      ]
    },
  {
   
      name: "qts2",
      options: [
        "Well Articulated",
        "Fairly Articulated",
        "Satisfactorily Articulated",
        "Unsatisfactorily Articulated",
      ],
    },
   
  {
   
      name: "qts3",
      options: [
        "Uses Many example",
        "Uses examples adequately",
        "Infrequently uses examples",
        "Never uses examples",
      ],
    },
    
  {
   
      name: "qts4",
      options: [
        "Very Well Organised",
        "Fairly Well Organised",
        "Satisfactorily Well Organised",
        "Unsystematic",
      ],
   },
  {
   
      name: "qts5",
      options: [
        "Very Good usage",
        "Satisfactory usage",
        "Rarely uses",
        "Never uses",
      ],
    },
  {
    
      name: "qts6",
      options: [
        "Ample opportunity",
        "Occasional opportunity",
        "Rare opportunity",
        "Discourages Questions",
      ],
    },
  {
   
      name: "qts7",
      options: [
        " Very regular",
        "Fairly regular",
        "Irregular",
        "Takes few classes",
      ],
    }, 
  {
    
      name: "qts8",
      options: [
        "Impartial",
        "Generally fair",
        "Occasionally partial",
        "Always Biased",
      ],
  },
  {
    
      name: "qts9",
      options: [
        "Extremely helpful",
        "Usually helpful",
        "Avoids Addressing",
        "Unhelpful",
      ],
    },
  {
      name: "qts10",
      options: ["Excellent", "Very Good", "Satisfactory", "Poor"],
  }
];
export default steps;
