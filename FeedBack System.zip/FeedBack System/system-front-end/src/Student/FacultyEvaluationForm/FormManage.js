import React from 'react'
import FormRadio from './FormRadio.js'
import Remark from './Remark.js'

function FormManage(props) {
     
    const {options,values}=props;
    
        switch (props.steps) {
          case 0:
            return <FormRadio  handleChange={props.handleChange} value={values.qts1} qts={options[0]}/>;
          case 1:
            return <FormRadio handleChange={props.handleChange} value={values.qts2} qts={options[1]}/>;
          case 2:
            return  <FormRadio handleChange={props.handleChange} value={values.qts3} qts={options[2]}/>;
          case 3:
            return <FormRadio  handleChange={props.handleChange} value={values.qts4} qts={options[3]}/>;
          case 4:
            return <FormRadio handleChange={props.handleChange} value={values.qts5} qts={options[4]}/>;
          case 5:
            return  <FormRadio handleChange={props.handleChange} value={values.qts6} qts={options[5]}/>;
          case 6:
            return <FormRadio  handleChange={props.handleChange} value={values.qts7} qts={options[6]}/>;
          case 7:
            return <FormRadio handleChange={props.handleChange} value={values.qts8} qts={options[7]}/>;
          case 8:
            return  <FormRadio handleChange={props.handleChange} value={values.qts9} qts={options[8]}/>;
          case 9:
            return  <FormRadio handleChange={props.handleChange} value={values.qts10} qts={options[9]}/>;
          case 10:
            return <Remark handleRemarkChange={props.handleRemarkChange} remark={props.remark} />;
          default:
            return "Unknown step";
        }
}

export default FormManage
 