import React from 'react'
import TextField from '@material-ui/core/TextField';

function Remark(props) {
    return (
        <div>
        <TextField
          id="filled-password-input"
          label="Remark"
          type="Text"
          autoComplete="current-password"
          variant="outlined"
          value={props.remark}
          onChange={props.handleRemarkChange}
          fullWidth={true}
        />
        </div>
    )
}

export default Remark;
