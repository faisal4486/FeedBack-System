import React from "react";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormControl from "@material-ui/core/FormControl";

export default function RadioButtonsGroup(props) {
  const { handleChange, value, qts } = props;
  const { name, options } = qts;
  console.log(name)
  console.log(value)

  return (
    <FormControl component="fieldset">
      <RadioGroup
        column
        aria-label="position"
        name="position"
        value={value}
        onChange={handleChange(`${name}`)}
        required={true}
        >
        
        <FormControlLabel
          value="2.5"
          control={<Radio color="primary" />}
          label={options[0]}
        />

        <FormControlLabel
          value="5" 
          control={<Radio color="primary" />}
          label={options[1]}
        />

        <FormControlLabel
          value="7.5"
          control={<Radio color="primary" />}
          label={options[2]}
        />

        <FormControlLabel
          value="10"
          control={<Radio color="primary" />}
          label={options[3]}
        />

      </RadioGroup>
    </FormControl>
  );
}
