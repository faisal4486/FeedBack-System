import React from "react";
import Typography from "@material-ui/core/Typography";
import Paper from "@material-ui/core/Paper";
import { makeStyles } from "@material-ui/core/styles";
import { Grid } from "@material-ui/core";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormControl from "@material-ui/core/FormControl";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    minHeight: "300px",
    padding: "10px 30px",
  },
}));

function Form3(props) {
  const { values, handleEfforts } = props;
  console.log(values)
  const classes = useStyles();
  return (
    <Paper elevation={0}>
      <div className={classes.root}>
        <Grid container spacing={3}>
          

           {/* 1 qts */}

          <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
             1) How many journals / technical or business magazines do you study?
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
             
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.journals}
                onChange={handleEfforts('journals')}
                >

                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label="Many"
                />

                <FormControlLabel
                  value="3"
                  control={<Radio color="primary" />}
                  label="Some" 
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Few"
                />
                
                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="None"
                />
              </RadioGroup>
            </FormControl>
          </Grid>

           {/* 12Th Score */}

          <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
             2) How many seminars you have attended during the last 2 years?
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
             
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.seminars}
                onChange={handleEfforts('seminars')}
                >

                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label="Many"
                />

                <FormControlLabel
                  value="3"
                  control={<Radio color="primary" />}
                  label="Some" 
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Few"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="None"
                />
              </RadioGroup>
            </FormControl>
          </Grid>

          {/* Graduation Score */}

          <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
             3) Have you ever written any research paper/ article/ abstract?
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
             
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.research}
                onChange={handleEfforts('research')}
                >

                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label="Many"
                />

                <FormControlLabel
                  value="3"
                  control={<Radio color="primary" />}
                  label="Some" 
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Few"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="None"
                />
              </RadioGroup>
            </FormControl>
          </Grid>
        
           
            {/* Word Processing  */}
           
            <Grid item xs={12}>
            <Typography variant="body1">
            4) How often do you generally
            </Typography>
          </Grid>

            <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {"    "}
                i) Participate in class discussion
            </Typography>
          </Grid>

          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
             
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.discussion}
                onChange={handleEfforts('discussion')}
                >

                <FormControlLabel
                  value="3"
                  control={<Radio color="primary" />}
                  label="Always"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Sometimes" 
                />

                <FormControlLabel
                  value="0"
                  control={<Radio color="primary" />}
                  label="Never"
                />

              </RadioGroup>
            </FormControl>
          </Grid>
          {/* File Navigation */}
            <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
             ii) Revise the lessons/topics taught in the class
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
             
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.revision}
                onChange={handleEfforts('revision')}
                >

                <FormControlLabel
                  value="3"
                  control={<Radio color="primary" />}
                  label="Always"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Sometimes" 
                />

                <FormControlLabel
                  value="0"
                  control={<Radio color="primary" />}
                  label="Never"
                />
              </RadioGroup>
            </FormControl>
          </Grid>
      
        {/* Internet Browsing */}
            <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
             iii) Try to logically approach a problem
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
             
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.logically}
                onChange={handleEfforts('logically')}
                >

                <FormControlLabel
                  value="3"
                  control={<Radio color="primary" />}
                  label="Always"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Sometimes" 
                />

                <FormControlLabel
                  value="0"
                  control={<Radio color="primary" />}
                  label="Never"
                />
              </RadioGroup>
            </FormControl>
          </Grid>
          {/* Emailing */}
            <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
              iv) Try to learn new things on my own
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
             
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.learn}
                onChange={handleEfforts('learn')}
                >

                <FormControlLabel
                  value="3"
                  control={<Radio color="primary" />}
                  label="Always"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Sometimes" 
                />

                <FormControlLabel
                  value="0"
                  control={<Radio color="primary" />}
                  label="Never"
                />
              </RadioGroup>
            </FormControl>
          </Grid>

          </Grid>
      </div>
    </Paper>
  );
}
export default Form3;

