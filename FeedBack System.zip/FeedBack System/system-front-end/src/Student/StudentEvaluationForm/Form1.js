import React from "react";
import Typography from "@material-ui/core/Typography";
import Paper from "@material-ui/core/Paper";
import { makeStyles } from "@material-ui/core/styles";
import { Grid } from "@material-ui/core";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormControl from "@material-ui/core/FormControl";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    minHeight: "300px",
    padding: "10px 30px",
  },
}));

function Form1(props) {
  const { values, handleCategory } = props;
  console.log(values)
  const classes = useStyles();
  return (
    <Paper elevation={0}>
      <div className={classes.root}>
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Typography variant="body1">
               Please Provide the detail of your qualification
            </Typography>
          </Grid>

           {/* 10TH Score */}

          <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
             1) 10<sup>th</sup> Score
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
             
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.tenth}
                onChange={handleCategory('tenth')}
                required={true}
                >

                <FormControlLabel
                  value="6"
                  control={<Radio  required={true} color="primary" />}
                  label=">75%"
                />

                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label=">60%" 
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label=">50%"
                />
                
                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label=">40%"
                />
              </RadioGroup>
            </FormControl>
          </Grid>

           {/* 12Th Score */}

          <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
             2) 12<sup>th</sup> Score
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
             
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.twelth}
                onChange={handleCategory('twelth')}
                >

                <FormControlLabel
                  value="8"
                  control={<Radio color="primary" />}
                  label=">75%"
                />

                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label=">60%" 
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label=">50%"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label=">40%"
                />
              </RadioGroup>
            </FormControl>
          </Grid>

          {/* Graduation Score */}

          <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
             3) Graduation Score
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
             
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.graduation}
                onChange={handleCategory('graduation')}
                >

                <FormControlLabel
                  value="6"
                  control={<Radio color="primary" />}
                  label=">75%"
                />

                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label=">60%" 
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label=">50%"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label=">40%"
                />
              </RadioGroup>
            </FormControl>
          </Grid>
          <Grid item xs={12}>
            <Typography variant="body1">
            Please rate your understanding of the following ICT application
            </Typography>
          </Grid>
           
            {/* Word Processing  */}
           
            <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
             1) Word Processing
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
             
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.wordProcessing}
                onChange={handleCategory('wordProcessing')}
                required={true}
                >

                <FormControlLabel
                  value="6"
                  control={<Radio color="primary" />}
                  label="Excellent"
                />

                <FormControlLabel
                  value="5"
                  control={<Radio color="primary" />}
                  label="Good" 
                />

                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label="Fair"
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Low"
                />
              </RadioGroup>
            </FormControl>
          </Grid>
          {/* File Navigation */}
            <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
             2) File Navigation
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
             
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.fileNavigation}
                onChange={handleCategory('fileNavigation')}
                >

                <FormControlLabel
                  value="6"
                  control={<Radio color="primary" />}
                  label="Excellent"
                />

                <FormControlLabel
                  value="5"
                  control={<Radio color="primary" />}
                  label="Good" 
                />

                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label="Fair"
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Low"
                />
              </RadioGroup>
            </FormControl>
          </Grid>
      
        {/* Internet Browsing */}
            <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
             3) Internet Browsing
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
             
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.internetBrowsing}
                onChange={handleCategory('internetBrowsing')}
                >

                <FormControlLabel
                  value="6"
                  control={<Radio color="primary" />}
                  label="Excellent"
                />

                <FormControlLabel
                  value="5"
                  control={<Radio color="primary" />}
                  label="Good" 
                />

                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label="Fair"
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Low"
                />
              </RadioGroup>
            </FormControl>
          </Grid>
          {/* Emailing */}
            <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
             4) Emailing
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
             
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.emailing}
                onChange={handleCategory('emailing')}
                >

                <FormControlLabel
                  value="6"
                  control={<Radio color="primary" />}
                  label="Excellent"
                />

                <FormControlLabel
                  value="5"
                  control={<Radio color="primary" />}
                  label="Good" 
                />

                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label="Fair"
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Low"
                />
              </RadioGroup>
            </FormControl>
          </Grid>

          {/* Presentation Tools */}
          <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
             5) Presentation Tools
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
             
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.presentationTools}
                onChange={handleCategory('presentationTools')}
                >

                <FormControlLabel
                  value="6"
                  control={<Radio color="primary" />}
                  label="Excellent"
                />

                <FormControlLabel
                  value="5"
                  control={<Radio color="primary" />}
                  label="Good" 
                />

                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label="Fair"
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Low"
                />
              </RadioGroup>
            </FormControl>
          </Grid>

          {/* Social networking sites */}
          <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
             6) Social networking sites
            </Typography>
          </Grid>

          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
             
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.socialNetworking}
                onChange={handleCategory('socialNetworking')}
                >

                <FormControlLabel
                  value="6"
                  control={<Radio color="primary" />}
                  label="Excellent"
                />

                <FormControlLabel
                  value="5"
                  control={<Radio color="primary" />}
                  label="Good" 
                />

                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label="Fair"
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Low"
                />
              </RadioGroup>
            </FormControl>
          </Grid>
        
         
          <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
             Why did you choose your stream? Pl. tick the relevant
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
             
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.stream}
                onChange={handleCategory('stream')}
              >

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="I like technological innovation/ management"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Parents / guardians' pressure" 
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="No other option"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Others."
                />
              </RadioGroup>
            </FormControl>
          </Grid>
          </Grid>
      </div>
    </Paper>
  );
}
export default Form1;



