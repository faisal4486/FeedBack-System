import React, { useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Stepper from "@material-ui/core/Stepper";
import Step from "@material-ui/core/Step";
import StepLabel from "@material-ui/core/StepLabel";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import FormHandler from "./FormHandler";
import axios from "axios";
import { Link } from "react-router-dom";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
  },
  type: {
    fontWeight: 900,
  },
  backButton: {
    marginRight: theme.spacing(1),
  },
  instructions: {
    marginTop: theme.spacing(1),
    marginBottom: theme.spacing(1),
    fontWeight: 600,
  },
  buttonConatiner: {
    paddingTop: "10px",
  },
  link: {
    textDecorationColor: theme.palette.primary,
  },
}));

function getSteps() {
  return ["Step 1", "Step 2", "Step 3", "Step 4", "Step 5"];
}

export default function StudentEvaluation() {
  const classes = useStyles();
  const [activeStep, setActiveStep] = useState(0);
  const [total1, setTotal1] = useState(0);
  const [total2, setTotal2] = useState(0);
  const [total3, setTotal3] = useState(0);
  const [total4, setTotal4] = useState(0);
  const [total5, setTotal5] = useState(0);
  const [category, setCategory] = useState({
    tenth: 0,
    twelth: 0,
    graduation: 0,
    wordProcessing: 0,
    fileNavigation: 0,
    internetBrowsing: 0,
    emailing: 0,
    presentationTools: 0,
    socialNetworking: 0,
    stream: "",
  });
  const [regularity, setRegularity] = useState({
    time: 0,
    schedules: 0,
    selfstudies: 0,
    library: 0,
    skip: 0,
    attendance: 0,
    activities: 0,
  });
  const [efforts, setEfforts] = useState({
    journals: 0,
    seminars: 0,
    research: 0,
    discussion: 0,
    revision: 0,
    logically: 0,
    learn: 0,
  });
  const [selfAssessment, setSelfAssessment] = useState({
    performance: 0,
    outcome: 0,
    documnetation: 0,
    development: 0,
    analytical: 0,
    solving: 0,
    knowledge: 0,
    managment: 0,
  });
  const [attitude, setAttitude] = useState({
    classmate: 0,
    teachers: 0,
    staff: 0,
    institution: 0,
    system: 0,
    teachers2: 0,
    peers: 0,
  });

  const value = { category, attitude, selfAssessment, efforts, regularity };
  const steps = getSteps();

  const studentData = JSON.parse(localStorage.getItem("studentData"));
  console.log(studentData)

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleCategory = (input) => (e) => {
    setCategory((prev) => {
      return {
        ...prev,
        [input]: e.target.value,
      };
    });
  };

  const handleRegularity = (input) => (e) => {
    setRegularity((prev) => {
      return {
        ...prev,
        [input]: e.target.value,
      };
    });
  };

  const handleEfforts = (input) => (e) => {
    setEfforts((prev) => {
      return {
        ...prev,
        [input]: e.target.value,
      };
    });
  };

  const handleSelfAssessment = (input) => (e) => {
    setSelfAssessment((prev) => {
      return {
        ...prev,
        [input]: e.target.value,
      };
    });
  };

  const handleAttitude = (input) => (e) => {
    setAttitude((prev) => {
      return {
        ...prev,
        [input]: e.target.value,
      };
    });
  };

  const sendData = ()=>{
    axios
    .post("/student/student_evaluation", {
      student_id: studentData.student_id,
      student_course: studentData.course,
      student_first_name: studentData.firstname,
      student_last_name: studentData.lastname,
      student_batch: studentData.batch,
      student_rollno:studentData.rollno,
      student_sem: studentData.semester,
      student_div: studentData.div,
      qts1: total1,
      qts2: total2,
      qts3: total3,
      qts4: total4,
      qts5: total5,
    })
    .then((result) => {
      console.log(result);
    })
    .catch((err) => {
      console.log(err);
    });
  }

  const handleSubmit = (e) => {
    Object.keys(category).forEach((key) => {
      var value = category[key];
      setTotal1((prev) => {
        return prev + parseInt(value);
      });
    });
    Object.keys(regularity).forEach((key) => {
      var value = regularity[key];
      setTotal2((prev) => {
        return prev + parseInt(value);
      });
    });
    Object.keys(efforts).forEach((key) => {
      var value = efforts[key];
      setTotal3((prev) => {
        return prev + parseInt(value);
      });
    });
    Object.keys(selfAssessment).forEach((key) => {
      var value = selfAssessment[key];
      setTotal4((prev) => {
        return prev + parseInt(value);
      });
    });
    Object.keys(attitude).forEach((key) => {
      var value = attitude[key];
      setTotal5((prev) => {
        return prev + parseInt(value);
      });
    });
    sendData();
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
    e.preventDefault();
  };

  return (
    <div className={classes.root}>
      <Stepper activeStep={activeStep} alternativeLabel>
        {steps.map((label) => (
          <Step key={label}>
            <StepLabel style={{ fontSize: "30px" }}>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>
      <div className={classes.buttonConatiner}>
        {activeStep === steps.length ? (
          <div>
            <Typography className={classes.instructions}>
              All steps completed
            </Typography>

            <Button
              component={Link}
              to={"/student/feedback"}
              variant="contained"
              color="primary"
              onClick={sendData}
              >
              Finish
            </Button>

          </div>
        ) : (
          <div>
            <FormHandler
              index={activeStep}
              values={value}
              handleCategory={handleCategory}
              handleAttitude={handleAttitude}
              handleEfforts={handleEfforts}
              handleSelfAssessment={handleSelfAssessment}
              handleRegularity={handleRegularity}
            />
            <div className={classes.buttonContainer}>
              <Button
                disabled={activeStep === 0}
                onClick={handleBack}
                className={classes.backButton}>
                Back
              </Button>

              {activeStep === steps.length - 1 ? (
                <Button
                  variant="contained"
                  color="primary"
                  onClick={handleSubmit}>
                  Submit
                </Button>
              ) : (
                <Button
                  variant="contained"
                  color="primary"
                  onClick={handleNext}>
                  Next
                </Button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
