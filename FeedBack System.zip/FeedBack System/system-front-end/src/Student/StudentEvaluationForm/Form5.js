import React from "react";
import Typography from "@material-ui/core/Typography";
import Paper from "@material-ui/core/Paper";
import { makeStyles } from "@material-ui/core/styles";
import { Grid } from "@material-ui/core";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormControl from "@material-ui/core/FormControl";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    minHeight: "300px",
    padding: "10px 30px",
  },
}));


function Form5(props) {
  const { values, handleAttitude } = props;
  console.log(values);
  const classes = useStyles();
  return (
    <Paper elevation={0}>
      <div className={classes.root}>
        <Grid container spacing={3}>
          {/* 1 qts */}

          <Grid item xs={12}>
            <Typography variant="body1">
              {" "}
              1) How often do you generally praise your
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <Typography variant="body1"> i) Classmates</Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.classmate}
                onChange={handleAttitude("classmate")}>
                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Always"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Sometimes"
                />

                <FormControlLabel
                  value="0"
                  control={<Radio color="primary" />}
                  label="Never"
                />
              </RadioGroup>
            </FormControl>
          </Grid>

          <Grid item xs={12} sm={6}>
            <Typography variant="body1"> ii) Teachers</Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.teachers}
                onChange={handleAttitude("teachers")}>
                <FormControlLabel
                  value="3"
                  control={<Radio color="primary" />}
                  label="Always"
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Sometimes"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Never"
                />
              </RadioGroup>
            </FormControl>
          </Grid>

          {/* Graduation Score */}

          <Grid item xs={12} sm={6}>
            <Typography variant="body1"> iii) Staff</Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.staff}
                onChange={handleAttitude("staff")}>
                <FormControlLabel
                  value="3"
                  control={<Radio color="primary" />}
                  label="Always"
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Sometimes"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Never"
                />
              </RadioGroup>
            </FormControl>
          </Grid>

          {/* Word Processing  */}

          <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {"    "}
              iv) Institution
            </Typography>
          </Grid>

          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.institution}
                onChange={handleAttitude("institution")}>
                <FormControlLabel
                  value="3"
                  control={<Radio color="primary" />}
                  label="Always"
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Sometimes"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Low"
                />
              </RadioGroup>
            </FormControl>
          </Grid>
          {/* File Navigation */}
          <Grid item xs={12} sm={6}>
            <Typography variant="body1"> v) System </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.system}
                onChange={handleAttitude("system")}>
                <FormControlLabel
                  value="3"
                  control={<Radio color="primary" />}
                  label="Always"
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Sometimes"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Never"
                />
              </RadioGroup>
            </FormControl>
          </Grid>

          {/* Internet Browsing */}
          <Grid item xs={12}>
            <Typography variant="body1">
              {" "}
              2) .How did you feel when criticized by
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <Typography variant="body1"> i)Teachers </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.teachers2}
                onChange={handleAttitude("teachers2")}>
                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Took It Positively"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Felt Offended"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Self Pity"
                />

                <FormControlLabel
                  value="0"
                  control={<Radio color="primary" />}
                  label="Ignored"
                />
              </RadioGroup>
            </FormControl>
          </Grid>
          {/* Emailing */}
          <Grid item xs={12} sm={6}>
            <Typography variant="body1"> ii) Peers</Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.peers}
                onChange={handleAttitude("peers")}>
                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Took It Positively"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Felt Offended"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Self Pity"
                />

                <FormControlLabel
                  value="0"
                  control={<Radio color="primary" />}
                  label="Ignored"
                />
              </RadioGroup>
            </FormControl>
          </Grid>
        </Grid>
      </div>
    </Paper>
  );
}
export default Form5;
