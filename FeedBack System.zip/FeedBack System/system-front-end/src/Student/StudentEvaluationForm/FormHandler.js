import React from 'react'
import Form1 from './Form1';
import Form2 from './Form2';
import Form3 from './Form3';
import Form4 from './Form4';
import Form5 from './Form5';

function FormHandler(props) {
  const {category,regularity,selfAssessment,efforts,attitude} = props.values;
 
  if(props.index === 0){
      return <Form1 values={category} handleCategory={props.handleCategory} />
  }
  if(props.index === 1){
      return <Form2 values={regularity} handleRegularity={props.handleRegularity}/>
  }
  if(props.index === 2){
      return <Form3 values={efforts} handleEfforts={props.handleEfforts}/>
  }
  if(props.index === 3){
    return <Form4 values={selfAssessment} handleSelfAssessment={props.handleSelfAssessment}/>
  }
  if(props.index === 4){
    return <Form5 values={attitude} handleAttitude={props.handleAttitude}/>
  }
}

export default FormHandler
