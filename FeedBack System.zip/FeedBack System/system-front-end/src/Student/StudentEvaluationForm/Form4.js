import React from "react";
import Typography from "@material-ui/core/Typography";
import Paper from "@material-ui/core/Paper";
import { makeStyles } from "@material-ui/core/styles";
import { Grid } from "@material-ui/core";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormControl from "@material-ui/core/FormControl";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    minHeight: "300px",
    padding: "10px 30px",
  },
}));



function Form4(props) {
  const { values, handleSelfAssessment } = props;
  console.log(values);
  const classes = useStyles();
  return (
    <Paper elevation={0}>
      <div className={classes.root}>
        <Grid container spacing={3}>
          {/* 1 qts */}

          <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
              1.If you have to evaluate your performance in the Semester, where
              do you place yourself?
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.performance}
                onChange={handleSelfAssessment("performance")}>
                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="<50%"
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="50-60%"
                />

                <FormControlLabel
                  value="3"
                  control={<Radio color="primary" />}
                  label="60-70%"
                />

                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label=">=75%"
                />
              </RadioGroup>
            </FormControl>
          </Grid>

          {/* 12Th Score */}

          <Grid item xs={12}>
            <Typography variant="body1">
              {" "}
              2) Please rate yourself on Technical Graduate Skills acquired. as
              a consequence of attending classes for the subject
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <Typography variant="body1"> i) Outcomes achieved</Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.outcome}
                onChange={handleSelfAssessment("outcome")}>
                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label="Excellent"
                />

                <FormControlLabel
                  value="3"
                  control={<Radio color="primary" />}
                  label="Good"
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Fair"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Low"
                />
              </RadioGroup>
            </FormControl>
          </Grid>

          {/* Graduation Score */}

          <Grid item xs={12} sm={6}>
            <Typography variant="body1"> ii) Documentation skills</Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.documnetation}
                onChange={handleSelfAssessment("documnetation")}>
                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label="Excellent"
                />

                <FormControlLabel
                  value="3"
                  control={<Radio color="primary" />}
                  label="Good"
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Fair"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Low"
                />
              </RadioGroup>
            </FormControl>
          </Grid>

          {/* Word Processing  */}

          <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {"    "}
              iii) Development skills
            </Typography>
          </Grid>

          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.development}
                onChange={handleSelfAssessment("development")}>
                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label="Excellent"
                />

                <FormControlLabel
                  value="3"
                  control={<Radio color="primary" />}
                  label="Good"
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Fair"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Low"
                />
              </RadioGroup>
            </FormControl>
          </Grid>
          {/* File Navigation */}
          <Grid item xs={12} sm={6}>
            <Typography variant="body1"> iv) Analytical skills</Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.analytical}
                onChange={handleSelfAssessment("analytical")}>
                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label="Excellent"
                />

                <FormControlLabel
                  value="3"
                  control={<Radio color="primary" />}
                  label="Good"
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Fair"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Low"
                />
              </RadioGroup>
            </FormControl>
          </Grid>

          {/* Internet Browsing */}
          <Grid item xs={12} sm={6}>
            <Typography variant="body1"> v) Problem solving skills</Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.solving}
                onChange={handleSelfAssessment("solving")}>
                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label="Excellent"
                />

                <FormControlLabel
                  value="3"
                  control={<Radio color="primary" />}
                  label="Good"
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Fair"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Low"
                />
              </RadioGroup>
            </FormControl>
          </Grid>
          {/* Emailing */}
          <Grid item xs={12} sm={6}>
            <Typography variant="body1"> vi) Fundamental knowledge</Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.knowledge}
                onChange={handleSelfAssessment("knowledge")}>
                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label="Excellent"
                />

                <FormControlLabel
                  value="3"
                  control={<Radio color="primary" />}
                  label="Good"
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Fair"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Low"
                />
              </RadioGroup>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
              vii) Project Management skills
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.managment}
                onChange={handleSelfAssessment("managment")}>
                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label="Excellent"
                />

                <FormControlLabel
                  value="3"
                  control={<Radio color="primary" />}
                  label="Good"
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Fair"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Low"
                />
              </RadioGroup>
            </FormControl>
          </Grid>
        </Grid>
      </div>
    </Paper>
  );
}
export default Form4;
