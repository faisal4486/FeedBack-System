import React from "react";
import Typography from "@material-ui/core/Typography";
import Paper from "@material-ui/core/Paper";
import { makeStyles } from "@material-ui/core/styles";
import { Grid } from "@material-ui/core";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormControl from "@material-ui/core/FormControl";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    minHeight: "300px",
    padding: "10px 30px",
  },
}));

function Form2(props) {
  const { values, handleRegularity } = props;
  console.log(values)
  const classes = useStyles();
  return (
    <Paper elevation={0}>
      <div className={classes.root}>
        <Grid container spacing={3}>
          

           {/* 1 qts */}

          <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
             1)  Are you normally on time for your classes
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
             
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.time}
                onChange={handleRegularity('time')}
                >

                <FormControlLabel
                  value="8"
                  control={<Radio color="primary" />}
                  label="Early"
                />

                <FormControlLabel
                  value="6"
                  control={<Radio color="primary" />}
                  label="Normal Time" 
                />

                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label="Late"
                />
                
                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Very Late"
                />
              </RadioGroup>
            </FormControl>
          </Grid>

           {/* 12Th Score */}

          <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
             2) How well are you able to follow your planned time schedules?
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
             
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.schedules}
                onChange={handleRegularity('schedules')}
                >

                <FormControlLabel
                  value="8"
                  control={<Radio color="primary" />}
                  label="Mostly"
                />

                <FormControlLabel
                  value="6"
                  control={<Radio color="primary" />}
                  label="Sometime" 
                />

                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label="Rareley"
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Never"
                />
              </RadioGroup>
            </FormControl>
          </Grid>

          {/* Graduation Score */}

          <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
             3) Besides your classes, how many hours do you spend on self-studies in a day?
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
             
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.selfstudies}
                onChange={handleRegularity('selfstudies')}
                >

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="0hrs"
                />

                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label="1-2hrs" 
                />

                <FormControlLabel
                  value="6"
                  control={<Radio color="primary" />}
                  label="3-4hrs"
                />

                <FormControlLabel
                  value="8"
                  control={<Radio color="primary" />}
                  label=">=5hrs"
                />
              </RadioGroup>
            </FormControl>
          </Grid>
        
           
            {/* Word Processing  */}
           
            <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
             4) Generally how often do you visit your library?
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
             
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.library}
                onChange={handleRegularity('library')}
                >

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Rarely"
                />

                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label="1-2 days" 
                />

                <FormControlLabel
                  value="6"
                  control={<Radio color="primary" />}
                  label="2-3 days"
                />

                <FormControlLabel
                  value="Daily"
                  control={<Radio color="primary" />}
                  label="Low"
                />
              </RadioGroup>
            </FormControl>
          </Grid>
          {/* File Navigation */}
            <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
             2) How often you skip your classes?
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
             
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.skip}
                onChange={handleRegularity('skip')}
                >

                <FormControlLabel
                  value="8"
                  control={<Radio color="primary" />}
                  label="Not At All"
                />

                <FormControlLabel
                  value="6"
                  control={<Radio color="primary" />}
                  label="Sometimes" 
                />

                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label="Very Often"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Always"
                />
              </RadioGroup>
            </FormControl>
          </Grid>
      
        {/* Internet Browsing */}
            <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
             6) What is your attendance in the course approximately?
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
             
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.attendance}
                onChange={handleRegularity('attendance')}
                >

                <FormControlLabel
                  value="12"
                  control={<Radio color="primary" />}
                  label="90-100%"
                />

                <FormControlLabel
                  value="10"
                  control={<Radio color="primary" />}
                  label="70-90%" 
                />

                <FormControlLabel
                  value="8"
                  control={<Radio color="primary" />}
                  label="50-70%"
                />

                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label="<50%"
                />
              </RadioGroup>
            </FormControl>
          </Grid>
          {/* Emailing */}
            <Grid item xs={12} sm={6}>
            <Typography variant="body1">
              {" "}
             7) Time outlay for other activities.
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
             
              <RadioGroup
                row
                aria-label="position"
                name="position"
                value={values.activities}
                onChange={handleRegularity('activities')}
                >

                <FormControlLabel
                  value="4"
                  control={<Radio color="primary" />}
                  label="Rarely"
                />

                <FormControlLabel
                  value="3"
                  control={<Radio color="primary" />}
                  label="Relatively Less" 
                />

                <FormControlLabel
                  value="2"
                  control={<Radio color="primary" />}
                  label="Moderate"
                />

                <FormControlLabel
                  value="1"
                  control={<Radio color="primary" />}
                  label="Relatively More"
                />
              </RadioGroup>
            </FormControl>
          </Grid>

          </Grid>
      </div>
    </Paper>
  );
}
export default Form2;



