import React,{useState} from "react";
import Avatar from "@material-ui/core/Avatar";
import Button from "@material-ui/core/Button";
import CssBaseline from "@material-ui/core/CssBaseline";
import TextField from "@material-ui/core/TextField";
import { Link } from "react-router-dom";
import Grid from "@material-ui/core/Grid";
import LockOutlinedIcon from "@material-ui/icons/LockOutlined";
import Typography from "@material-ui/core/Typography";
import axios from "axios"
import { makeStyles } from "@material-ui/core/styles";
import Container from "@material-ui/core/Container";

const useStyles = makeStyles((theme) => ({
  paper: {
    marginTop: theme.spacing(8),
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.primary.main,
  },
  form: {
    width: "100%",
    marginTop: theme.spacing(3),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
}));

export default function SignUp() {
  const classes = useStyles();

  const [fName,setFName] = useState("");
  const [lName,setLName] = useState("");
  const [collegeId,setCollegeId] = useState("");
  const [email,setEmail] = useState("");
  const [pass,setPass] = useState("");

  const handleFName = (e) =>{
    setFName(e.target.value)
  }
  const handleLName = (e) =>{
     setLName(e.target.value)
  }
  const handleCollegeId = (e) =>{
   setCollegeId(e.target.value)
  }
  const handleEmail = (e) =>{
   setEmail(e.target.value)
  }
  const handlePassword = (e) =>{
  setPass(e.target.value)
  }
 
  const submitSignUp = (e) =>{
   axios.post(`/auth/signup`,{
      id:collegeId,
      firstname:fName,
      lastname:lName,
      password:pass,
      email:email
   })
   .then(result=>{
     console.log(result)
    })
   .catch(err=>console.log(err))

    e.preventDefault();
  }
  return (
    <Container component="main" maxWidth="xs">
      <CssBaseline />
      <div className={classes.paper}>
        <Avatar className={classes.avatar}>
          <LockOutlinedIcon />
        </Avatar>
        <Typography component="h1" variant="h5">
          Sign up
        </Typography>
        <form className={classes.form} noValidate>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                autoComplete="fname"
                name="firstName"
                variant="outlined"
                onChange={handleFName}
                required
                fullWidth
                id="firstName"
                label="First Name"
                autoFocus
                value={fName}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                variant="outlined"
                required
                fullWidth
                onChange={handleLName}
                id="lastName"
                label="Last Name"
                name="lastName"
                autoComplete="lname"
                value={lName}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                variant="outlined"
                required
                fullWidth
                value={collegeId}
                onChange={handleCollegeId}
                id="id"
                label="College Id"
                name="Id"
                autoComplete="CollegeId"
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                variant="outlined"
                required
                fullWidth
                onChange={handleEmail}
                id="email"
                label="Email Address"
                name="email"
                autoComplete="email"
                value={email}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                variant="outlined"
                required
                fullWidth
                onChange={handlePassword}
                name="password"
                label="Password"
                type="password"
                id="password"
                autoComplete="current-password"
                value={pass}
              />
            </Grid>
          </Grid>
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            className={classes.submit}
            onClick={submitSignUp}
            >
            Sign Up
          </Button>
          <Grid container justify="flex-end">
            <Grid item>
              <Link to="/login" variant="body2">
                Already have an account? Sign in
              </Link>
            </Grid>
          </Grid>
        </form>
      </div>
    </Container>
  );
}
