import { useState, useCallback, useEffect } from 'react';

let logoutTimer;

export const useAdminAuth = () => {
  const [adminToken, setToken] = useState(false);
  const [tokenExpirationDate, setTokenExpirationDate] = useState();
  const [adminId, setUserId] = useState(false);

  const Adminlogin = useCallback((uid, token, expirationDate) => {
    setToken(token);
    setUserId(uid);
    const tokenExpirationDate =
      expirationDate || new Date(new Date().getTime() + 1000 * 60 * 60);
    setTokenExpirationDate(tokenExpirationDate);
    localStorage.setItem(
      'adminData',
      JSON.stringify({
        userId: uid,
        token: token,
        expiration: tokenExpirationDate.toISOString()
      })
    );
  }, []);

  const Adminlogout = useCallback(() => {
    setToken(null);
    setTokenExpirationDate(null);
    setUserId(null);
    localStorage.removeItem('adminData');
  }, []);

  useEffect(() => {
    if (adminToken && tokenExpirationDate) {
      const remainingTime = tokenExpirationDate.getTime() - new Date().getTime();
      logoutTimer = setTimeout(Adminlogout, remainingTime);
    } else {
      clearTimeout(logoutTimer);
    }
  }, [adminToken, Adminlogout, tokenExpirationDate]);

  useEffect(() => {
    const storedData = JSON.parse(localStorage.getItem('adminData'));
    if (
      storedData &&
      storedData.token &&
      new Date(storedData.expiration) > new Date()
    ) {
      Adminlogin(storedData.userId, storedData.token, new Date(storedData.expiration));
    }
  }, [Adminlogin]);
  console.log("admin" , adminId)
  return { adminToken, Adminlogin, Adminlogout, adminId };
};