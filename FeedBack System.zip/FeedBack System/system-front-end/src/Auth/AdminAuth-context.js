import { createContext } from 'react';

export const AdminAuthContext = createContext({
  isLoggedIn: false,
  userId: null,
  token: null,
  Adminlogin: () => {},
  Adminlogout: () => {}
});
