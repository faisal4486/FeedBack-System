import React, { useEffect, useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import Collapse from "@material-ui/core/Collapse";
import CreateIcon from "@material-ui/icons/Create";
import ExpandLess from "@material-ui/icons/ExpandLess";
import ExpandMore from "@material-ui/icons/ExpandMore";
import SettingsEthernetIcon from "@material-ui/icons/SettingsEthernet";
import Semester from "./Semester";
import Button from "@material-ui/core/Button";
import DeleteIcon from "@material-ui/icons/Delete";
import IconButton from "@material-ui/core/IconButton";
import AddSem from "./AddSem";
import DeleteFeild from "./DeleteFeild";
import axios from "axios";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    flexWrap: "wrap",
    maxWidth: "70vw",
    justifyContent: "center",
  },
  button: {
    marginRight: "5%",
  },
  deletebutton:{
    marginRight:"7.5%"
  },
  Item: {
    padding: "20px 50px",
  },
}));

export default function NestedList() {
  const classes = useStyles();

  const [dept, setDept] = useState([]);
  const [addSem, setAddSem] = useState(false);
  const [deptName,setDeptName] = useState("");
  const[deleteData,setDeleteData]=useState(false);
  const [deleteDeptName,setDeleteDeptName]=useState("");

  useEffect(() => {
    axios
      .get("/admin/dept")
      .then((res) => {
        console.log(res.data)
        let newValue = []
        res.data.map(item => {
            let abc = {
               name:item,
              isOpen:false
            }
            newValue.push(abc)
        })
        setDept(newValue);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  const handleDeleteOpen = (value) => {
    setDeleteData(true);
    setDeleteDeptName(value);
  };
 
  const handleDeleteClose = (value) => {
    if(value){
      axios.post(`/admin/remove-dept/`,{
        deptName:deleteDeptName
      })
      .then(res=>{
        console.log(res)
      })
      .catch(err=>{
        console.log(err)
      })
    }
    setDeleteData(false);
  };

  const handleClick = (i) => {
    console.log(i);
    let updatedList = dept.map((item) => {
      if (item.name === dept[i].name) {
        return { ...item, isOpen: !item.isOpen };
      }
      return item;
    });
    setDept(updatedList);
  };

  const handleClickOpen = (name) => {
    setDeptName(name)
    setAddSem(true);
  };

  const handleClose = () => {
    setAddSem(false);
  };
  return (
    <>
      <div>
        <List component="nav">
          {dept.map((item, index) => (
            <div id={index} className={classes.Item}>
              <ListItem>
                <ListItemIcon>
                  <SettingsEthernetIcon />
                </ListItemIcon>
                <ListItemText>{item.name}</ListItemText>
                <Button className={classes.deletebutton} onClick={()=>{handleDeleteOpen(item.name)}} >
                  <DeleteIcon color="primary" />
                </Button>

                <Button
                  variant="contained"
                  color="primary"
                  startIcon={<CreateIcon />}
                  className={classes.button}
                  onClick={() => handleClickOpen(item.name)}>
                  Add Sem
                </Button>

                {item.isOpen ? (
                  <IconButton onClick={() => handleClick(index)}>
                    <ExpandLess />
                  </IconButton>
                ) : (
                  <IconButton onClick={() => handleClick(index)}>
                    <ExpandMore />
                  </IconButton>
                )}
              </ListItem>
              <Collapse in={item.isOpen} timeout="auto" unmountOnExit>
                <Semester name={item.name} />
              </Collapse>
            </div>
          ))}
        </List>
      </div>
      {addSem && (
                <AddSem
                  handleClickOpen={handleClickOpen}
                  handleClose={handleClose}
                  open={addSem}
                  name={deptName}
                />
       )}
       {deleteData && <DeleteFeild open={deleteData} handleDeleteOpen={handleDeleteOpen} handleDeleteClose={handleDeleteClose} />}
    </>
  );
}
