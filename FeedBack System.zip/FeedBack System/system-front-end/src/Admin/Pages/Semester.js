import React, { useEffect, useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import Button from "@material-ui/core/Button";
import SettingsEthernetIcon from "@material-ui/icons/SettingsEthernet";
import DeleteIcon from "@material-ui/icons/Delete";
import CreateIcon from "@material-ui/icons/Create";
import IconButton from "@material-ui/core/IconButton";
import Collapse from "@material-ui/core/Collapse";
import ExpandLess from "@material-ui/icons/ExpandLess";
import ExpandMore from "@material-ui/icons/ExpandMore";
import Div from "./Div";
import AddDiv from "./AddDiv";
import DeleteFeild from "./DeleteFeild";
import axios from "axios";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    flexWrap: "wrap",
    maxWidth: "70vw",
    justifyContent: "center",
  },
  button: {
    marginRight: "5%",
  },
  deletebutton:{
    marginRight:"8.5%"
  },
  Item: {
    padding: "0px 0px 0px 25px",
  },
}));

function Semester(props) {
  const classes = useStyles();
  const [sem, setSem] = useState([]);
  const [addDiv, setAddDiv] = useState(false);
  const [semName, setSemName] = useState("");
  const [deleteData,setDeleteData]=useState(false);
  const [deleteSemName,setDeleteSemName]=useState("");
  
  useEffect(() => {
    axios
      .get(`/admin/sem/${props.name}`)
      .then((res) => {
        let newValue = []
        res.data.map(item => {
            let abc = {
              semester:item,
              isOpen:false
            }
            newValue.push(abc)
        })
        setSem(newValue);
        console.log(newValue)
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  const handleDeleteOpen = (value) => {
    setDeleteData(true);
    setDeleteSemName(value);
  };
 
  const handleDeleteClose = (value) => {
    if(value){
      axios.post(`/admin/remove-sem/`,{
        deptName:props.name,
        semester:deleteSemName
      })
      .then(res=>{
        console.log(res)
      })
      .catch(err=>{
        console.log(err)
      })
    }
    setDeleteData(false);
  };

  const handleClickOpen = (name) => {
    setSemName(name);
    setAddDiv(true);
  };

  const handleClose = () => {
    setAddDiv(false);
  };

  const handleClick = (i) => {
    // console.log(i);
    let updatedList = sem.map((item) => {
      if (item.semester === sem[i].semester) {
        return { ...item, isOpen: !item.isOpen };
      }
      return item;
    });
    setSem(updatedList);
    // console.log(dept[i].isOpen);
  };

  return (
    <List component="div" disablePadding>
      {sem.map((item, index) => (
        <div id={index} className={classes.Item}>
          <ListItem>
            <ListItemIcon>
              <SettingsEthernetIcon />
            </ListItemIcon>
            <ListItemText>Semester {item.semester}</ListItemText>
            <Button className={classes.deletebutton} onClick={()=>{handleDeleteOpen(item.semester)}} >
              <DeleteIcon color="primary" />
            </Button>

            <Button
              variant="contained"
              color="primary"
              startIcon={<CreateIcon />}
              className={classes.button}
              onClick={() => {
                handleClickOpen(item.semester);
              }}>
              Add Div
            </Button>

            {item.isOpen ? (
              <IconButton onClick={() => handleClick(index)}>
                <ExpandLess />
              </IconButton>
            ) : (
              <IconButton onClick={() => handleClick(index)}>
                <ExpandMore />
              </IconButton>
            )}
          </ListItem>
          <Collapse in={item.isOpen} timeout="auto" unmountOnExit>
            <Div name={props.name} sem={item.semester} />
          </Collapse>
        </div>
      ))}
      {addDiv && (
        <AddDiv
          handleClickOpen={handleClickOpen}
          handleClose={handleClose}
          open={addDiv}
          deptName={props.name}
          sem={semName}
        />
      )}
      {deleteData && <DeleteFeild open={deleteData} handleDeleteOpen={handleDeleteOpen} handleDeleteClose={handleDeleteClose} />}
    </List>
  );
}

export default Semester;
