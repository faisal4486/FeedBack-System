import React from "react";

function Home(props) {
  return <h3>Welcome to admin panel</h3>;
}
export default Home;
