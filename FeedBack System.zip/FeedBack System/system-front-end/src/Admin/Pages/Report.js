import React, { useState, useEffect } from "react";
import Chart from "./ReportPage/Chart";
import Tables from "./ReportPage/Tables";
import ReportSelect from "./ReportPage/ReportSelect";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import Remark from "./ReportPage/Remark";
import axios from "axios";
import { makeStyles } from "@material-ui/core/styles";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "center",
    color: theme.palette.text.secondary,
  },
}));

function Report() {
  const classes = useStyles();
  const [selectDetails, setSelectDetails] = useState([]);
  const [tableData, setTableData] = useState([]);

  const [len, setLen] = useState(0);

  const handleSelectOver = (item) => {

    setSelectDetails(item);
    console.log(item);
    axios.get(`/faculty/student_evaluation/${item.dept}/${item.sem}/${item.div}`)
    .then(result=>{console.log(result)})
    .catch(err=>{console.log(err)})
    
    axios
      .get(
        `/faculty/faculty_evaluation/${item.dept}/${item.sem}/${item.div}/${item.subject}/${item.faculty}`
      )
      .then((result) => {
        console.log(result.data);
        setLen(result.data.length);
        setTableData(result.data);
      })
      .catch((err) => {
        console.log(err);
      });
      
  };

  return (  
    <div className={classes.root}>
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <ReportSelect handleSelectOver={handleSelectOver} />
        </Grid>
        <Grid item xs={12}>
          <Chart chartData={tableData} len={len} />
        </Grid>
        <Grid item xs={12} s={12} md={6}>
          <Tables tableData={tableData} />
        </Grid>
        <Grid item xs={12} s={12} md={6}>
          <Remark selectDetails={selectDetails}  tableData = {tableData} />
        </Grid>
      </Grid>
    </div>
  );
}

export default Report;
