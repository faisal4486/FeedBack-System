import React, { useEffect, useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import Button from "@material-ui/core/Button";
import SettingsEthernetIcon from "@material-ui/icons/SettingsEthernet";
import DeleteIcon from "@material-ui/icons/Delete";
import CreateIcon from "@material-ui/icons/Create";
import IconButton from "@material-ui/core/IconButton";
import Collapse from "@material-ui/core/Collapse";
import ExpandLess from "@material-ui/icons/ExpandLess";
import ExpandMore from "@material-ui/icons/ExpandMore";
import Faculty from "./Faculty";
import AddFaculty from "./AddFaculty";
import DeleteFeild from "./DeleteFeild";
import axios from "axios";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    flexWrap: "wrap",
    maxWidth: "70vw",
    justifyContent: "center",
  },
  button: {
    marginRight: "5%",
  },
  Item: {
    padding: "0px 0px 0px 25px",
  },
}));

function Subject(props) {

  const classes = useStyles();
  // const [data,setData]=useState([]);
  const [sub, setSub] = useState([]);
  const [addFaculty,setAddFaculty] = useState(false);
  const [subName,setSubName] = useState("");
  const [deleteSubName,setDeleteSubName]=useState("");
  const [deleteData, setDeleteData] = useState(false);

  useEffect(() => {
    axios
      .get(`/admin/subjects/${props.name}/${props.sem}/${props.div}`)
      .then((res) => {
        let subject = [];
        let subjects = res.data[0].subjects;
        
         subjects.map(item => {
           let value = {
             name : item.subjectName,
             isOpen : false
           }
           return(
             subject.push(value)
           )
         })
        setSub(subject);
      })
      .catch((err) => {
        console.log(err);
      });
  },[]);

  const handleDeleteOpen = (value) => {
    setDeleteData(true);
    setDeleteSubName(value);
  };
 
  const handleDeleteClose = (value) => {
    if(value){
      axios.post(`/admin/remove-subject/`,{
        deptName:props.name,
        semester:props.sem,
        div:props.div,
        subjectName:deleteSubName
      })
      .then(res=>{
        console.log(res)
      })
      .catch(err=>{
        console.log(err)
      })
    }
    setDeleteData(false);
  };

  const handleClickOpen = (name) => {
    setAddFaculty(true);
    setSubName(name);
  };

  const handleClose = () => {
    setAddFaculty(false);
  };


  const handleClick = (i) => {
    let updatedList = sub.map((item) => {
      if (item.name === sub[i].name) {
        return { ...item, isOpen: !item.isOpen };
      }
      return item;
    });

   
    setSub(updatedList);
  };

  return (
    <List component="div" disablePadding>
      {sub.map((item, index) => (
        <div id={index} className={classes.Item}>

          <ListItem>
            <ListItemIcon>
              <SettingsEthernetIcon />
            </ListItemIcon>
            <ListItemText>{item.name}</ListItemText>
            <Button className={classes.button} onClick={()=>{handleDeleteOpen(item.name)}} >
              <DeleteIcon color="primary" />
            </Button>

            <Button
              variant="contained"
              color="primary"
              startIcon={<CreateIcon />}
              className={classes.button}
              onClick={() => {
                handleClickOpen(item.name);
              }}>
              Add Faculty  
            </Button>

            {item.isOpen ? (
              <IconButton onClick={() => handleClick(index)}>
                <ExpandLess />
              </IconButton>
            ) : (
              <IconButton onClick={() => handleClick(index)}>
                <ExpandMore />
              </IconButton>
            )}
          </ListItem>
          <Collapse in={item.isOpen} timeout="auto" unmountOnExit>
            <Faculty subjectName={item.name} name={props.name} sem={props.sem} div={props.div}/>
          </Collapse>
        </div>
      ))}
      {addFaculty && (
        <AddFaculty
          handleClickOpen={handleClickOpen}
          handleClose={handleClose}
          open={addFaculty}
          deptName={props.name}
          sem={props.sem}
          div={props.div}
          subject={subName}
        />
      )}
      {deleteData && <DeleteFeild open={deleteData} handleDeleteOpen={handleDeleteOpen} handleDeleteClose={handleDeleteClose} />}
    </List>
  );
}

export default Subject;


