import React, { useEffect, useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import Button from "@material-ui/core/Button";
import SettingsEthernetIcon from "@material-ui/icons/SettingsEthernet";
import DeleteIcon from "@material-ui/icons/Delete";
import DeleteFeild from "./DeleteFeild";
import axios from "axios";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    flexWrap: "wrap",
    maxWidth: "70vw",
    justifyContent: "center",
  },
  button: {
    marginRight: "31.5%",
  },
  Item: {
    padding: "0px 0px 0px 50px",
  },
}));

function Faculty(props) {

  const classes = useStyles();
  const [faculty, setFaculty] = useState([]);
  const [deleteFacultyName,setDeleteFacultyName]=useState("");
  const [deleteData, setDeleteData] = useState(false);

  useEffect(() => {
    axios
      .get(`/admin/subjects/${props.name}/${props.sem}/${props.div}`)
      .then((res) => {
           
        let subjects = res.data[0].subjects;
            subjects.map((item) => {
               if(item.subjectName === props.subjectName){
                 setFaculty(item.faculty)
               }
            })

      })
      .catch((err) => {
        console.log(err);
      });
  },[]);

const handleDeleteOpen = (value) => {
    setDeleteData(true);
    setDeleteFacultyName(value);
  };
 
  const handleDeleteClose = (value) => {
    if(value){
      axios.post(`/admin/remove-faculty/`,{
        deptName:props.name,
        semester:props.sem,
        div:props.div,
        subjectName:props.subjectName,
        faculty:deleteFacultyName
      })
      .then(res=>{
        console.log(res)
      })
      .catch(err=>{
        console.log(err)
      })
    }
    setDeleteData(false);
  };

  return (
    <List component="div" disablePadding>
      {faculty.map((item, index) => (
        <div id={index} className={classes.Item}>

          <ListItem>
            <ListItemIcon>
              <SettingsEthernetIcon />
            </ListItemIcon>
            <ListItemText>{item}</ListItemText>
            <Button className={classes.button} onClick={()=>{handleDeleteOpen(item)}}>
              <DeleteIcon color="primary" />
            </Button>
          </ListItem>
        </div>
      ))}
      {deleteData && <DeleteFeild open={deleteData} handleDeleteOpen={handleDeleteOpen} handleDeleteClose={handleDeleteClose} />}
    </List>
  );
}

export default Faculty;


