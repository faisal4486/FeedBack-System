import React, { useState, useEffect } from "react";
import { withStyles, makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import Button from "@material-ui/core/Button";
import axios from "axios";

const StyledTableCell = withStyles((theme) => ({
  head: {
    backgroundColor: theme.palette.common.white,
    color: theme.palette.common.black,
  },
  body: {
    fontSize: 14,
  },
}))(TableCell);

const StyledTableRow = withStyles((theme) => ({
  root: {
    "&:nth-of-type(odd)": {
      backgroundColor: theme.palette.action.hover,
    },
  },
}))(TableRow);

const useStyles = makeStyles({
  table: {
    minWidth: 400,
  },
  padding: {
    margin: "0 10px 0 10px",
  },
});

export default function Remark(props) {
  const { selectDetails } = props;
  const classes = useStyles();
  const [remark, setRemark] = useState(props.tableData);

  //   console.log(props);

  useEffect(() => {
    setRemark(props.tableData);
  }, [props.tableData]);

  const handleGoodFeedback = () => {
    axios
      .get(
        `/faculty/Positiveremark//${selectDetails.dept}/${selectDetails.sem}/${selectDetails.div}/${selectDetails.subject}/${selectDetails.faculty}`
      )
      .then((result) => {
        console.log(result);
        setRemark(result.data);
      })
      .catch((err) => console.log(err));
  };

  const handleBadFeedback = () => {
    axios
      .get(
        `/faculty/Negativeremark//${selectDetails.dept}/${selectDetails.sem}/${selectDetails.div}/${selectDetails.subject}/${selectDetails.faculty}`
      )
      .then((result) => {
        console.log(result);
        setRemark(result.data);
      })
      .catch((err) => console.log(err));
  };

  return (
    <TableContainer component={Paper}>
      <Table className={classes.table} aria-label="customized table">
        <TableHead>
          <TableRow>
            <StyledTableCell>
              <Button
                variant="contained"
                color="primary"
                className={classes.padding}
                onClick={handleGoodFeedback}>
                Good Feedbacks
              </Button>
              <Button
                variant="contained"
                color="primary"
                className={classes.padding}
                onClick={handleBadFeedback}>
                Improvements
              </Button>
            </StyledTableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {remark.map((row, index) => (
            <StyledTableRow key={index}>
              <StyledTableCell component="th" scope="row">
                {row.remark}
              </StyledTableCell>
            </StyledTableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
