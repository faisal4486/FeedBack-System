import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import axios from "axios";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    padding: theme.spacing(2),
    textAlign: "center",
    // color: theme.palette.text.secondary,
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
}));

function ReportSelect(props) {
  const classes = useStyles();
  const [getdept, getsetDept] = React.useState([]);
  const [getsem, getsetSem] = React.useState([]);
  const [getdiv, getsetDiv] = React.useState([]);
  const [getsubjects, getsetSubjects] = React.useState([]);
  const [getfaculty, getsetFaculty] = React.useState([]);
  const [dept, setDept] = React.useState("");
  const [sem, setSem] = React.useState("");
  const [div, setDiv] = React.useState("");
  const [subject, setSubject] = React.useState("");
  const [faculty, setFaculty] = React.useState("");

  const handleChangeDept = (event) => {
    setDept(event.target.value);
  };
  const handleChangeSem = (event) => {
    setSem(event.target.value);
  };
  const handleChangeDiv = (event) => {
    setDiv(event.target.value);
  };
  const handleChangeSubject = (event) => {
    setSubject(event.target.value);
  };
  const handleChangeFaculty = (event) => {
    setFaculty(event.target.value);
    const item = {
      dept: dept,
      sem: sem,
      div: div,
      subject: subject,
      faculty: event.target.value,
    };
    return props.handleSelectOver(item);
  };

  const handleOpenDept = () => {
    axios
      .get("/admin/dept")
      .then((res) => {
        getsetDept(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleOpenSem = () => {
    axios
      .get(`/admin/sem/${dept}`)
      .then((res) => {
        getsetSem(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleOpenDiv = () => {
    axios
      .get(`/admin/div/${dept}/${sem}`)
      .then((res) => {
        getsetDiv(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleOpenSubject = () => {
    axios
      .get(`/admin/subjects/${dept}/${sem}/${div}`)
      .then((res) => {
        getsetSubjects(res.data[0].subjects);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleOpenFaculty = () => {
    axios
      .get(`/admin/subjects/${dept}/${sem}/${div}`)
      .then((res) => {
        let subjects = res.data[0].subjects;
        subjects.map((item) => {
          if (item.subjectName === subject) {
            getsetFaculty(item.faculty);
          }
        });
      })
      .catch((err) => {
        console.log(err);
      });
  };

  return (
    <div className={classes.root}>
      <Paper>
        <Grid container spacing={2}>
          <Grid item xs={3}>
            <FormControl className={classes.formControl}>
              <InputLabel id="demo-simple-select-outlined-label">
                Department
              </InputLabel>
              <Select
                labelId="demo-simple-select-outlined-label"
                id="demo-simple-select-outlined"
                value={dept}
                onChange={handleChangeDept}
                onOpen={handleOpenDept}
                label="year">
                {getdept.map((value) => {
                  return <MenuItem value={value}>{value}</MenuItem>;
                })}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={2}>
            <FormControl className={classes.formControl}>
              <InputLabel id="demo-simple-select-outlined-label">
                Semester
              </InputLabel>
              <Select
                labelId="demo-simple-select-outlined-label"
                id="demo-simple-select-outlined"
                value={sem}
                onChange={handleChangeSem}
                onOpen={handleOpenSem}
                label="year">
                {getsem.map((value) => {
                  return <MenuItem value={value}>{value}</MenuItem>;
                })}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={2}>
            <FormControl className={classes.formControl}>
              <InputLabel id="demo-simple-select-outlined-label">
                Division
              </InputLabel>
              <Select
                labelId="demo-simple-select-outlined-label"
                id="demo-simple-select-outlined"
                value={div}
                onChange={handleChangeDiv}
                onOpen={handleOpenDiv}
                label="year">
                {getdiv.map((value) => {
                  return <MenuItem value={value.div}> {value.div} </MenuItem>;
                })}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={3}>
            <FormControl className={classes.formControl}>
              <InputLabel id="demo-simple-select-outlined-label">
                Subject
              </InputLabel>
              <Select
                labelId="demo-simple-select-outlined-label"
                id="demo-simple-select-outlined"
                value={subject}
                onChange={handleChangeSubject}
                onOpen={handleOpenSubject}
                label="year">
                {getsubjects.map((value) => {
                  return (
                    <MenuItem value={value.subjectName}>
                      {value.subjectName}
                    </MenuItem>
                  );
                })}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={2}>
            <FormControl className={classes.formControl}>
              <InputLabel id="demo-simple-select-outlined-label">
                Faculty
              </InputLabel>
              <Select
                labelId="demo-simple-select-outlined-label"
                id="demo-simple-select-outlined"
                value={faculty}
                onChange={handleChangeFaculty}
                onOpen={handleOpenFaculty}
                label="year">
                {getfaculty.map((value) => {
                  return <MenuItem value={value}>{value}</MenuItem>;
                })}
              </Select>
            </FormControl>
          </Grid>
        </Grid>
      </Paper>
    </div>
  );
}
export default ReportSelect;
