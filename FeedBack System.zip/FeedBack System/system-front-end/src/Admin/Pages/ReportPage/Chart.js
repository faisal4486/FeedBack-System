import React, { useState, useEffect } from "react";
import { Line ,Bar } from "react-chartjs-2";
import { makeStyles } from "@material-ui/core/styles";

const useStyles = makeStyles((theme) => ({
  root: {},
}));

function Chart(props) {
  const classes = useStyles();
  const [qts1, setQts1] = useState(0);
  const [qts2, setQts2] = useState(0);
  const [qts3, setQts3] = useState(0);
  const [qts4, setQts4] = useState(0);
  const [qts5, setQts5] = useState(0);
  const [qts6, setQts6] = useState(0);
  const [qts7, setQts7] = useState(0);
  const [qts8, setQts8] = useState(0);
  const [qts9, setQts9] = useState(0);
  const [qts10, setQts10] = useState(0);
  // const [chartData,setChartData]=useState([]);
  useEffect(()=>{
    props.chartData.map((item)=>{
      setQts1(prev=>{
        return prev+item.student_feedback.qts1;
      });
      setQts2(prev=>{
        return prev+item.student_feedback.qts2;
      });
      setQts3(prev=>{
        return prev+item.student_feedback.qts3;
      });
      setQts4(prev=>{
        return prev+item.student_feedback.qts4;
      });
      setQts5(prev=>{
        return prev+item.student_feedback.qts5;
      });
      setQts6(prev=>{
        return prev+item.student_feedback.qts6;
      });
      setQts7(prev=>{
        return prev+item.student_feedback.qts7;
      });
      setQts8(prev=>{
        return prev+item.student_feedback.qts8;
      });
      setQts9(prev=>{
        return prev+item.student_feedback.qts9;
      });
      setQts10(prev=>{
        return prev+item.student_feedback.qts10;
      });
    })  
  },[props.chartData])

  return (
    <div className={classes.root}>
      <Line
        data={{
          labels: [
            "Knowledge",
            "Ability to Explain",
            "Use of examples",
            "Teaching Material",
            "Use of training aids",
            "Opportunity to questions",
            "Engagement",
            "Impartiality",
            "Student Problem solving",
            "Overall",
          ],
          datasets: [
            {
              label: "Average Score",
              data: [
                (qts1 / props.len) * 10,
                (qts2 / props.len) * 10,
                (qts3 / props.len) * 10,
                (qts4 / props.len) * 10,
                (qts5 / props.len) * 10,
                (qts6 / props.len) * 10,
                (qts7 / props.len) * 10,
                (qts8 / props.len) * 10,
                (qts9 / props.len) * 10,
                (qts10 / props.len) * 10,
              ],
              fill: true,
              borderColor: "#3f51b5",
              // backgroundColor:"#3f51b5",
              tension: 0.1,
            },
          ],
        }}
        width={100}
        height={30}
        options={{
          title: {
            display: true,
            text: "Largest Cities In New York",
            fontSize: 25,
          },
          legend: {
            display: true,
            position: "buttom",
          }
        }}
      />
    </div>
  );
}
export default Chart;
