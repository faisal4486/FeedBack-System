import React, { useEffect, useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import Button from "@material-ui/core/Button";
import SettingsEthernetIcon from "@material-ui/icons/SettingsEthernet";
import DeleteIcon from "@material-ui/icons/Delete";
import CreateIcon from "@material-ui/icons/Create";
import IconButton from "@material-ui/core/IconButton";
import Collapse from "@material-ui/core/Collapse";
import ExpandLess from "@material-ui/icons/ExpandLess";
import ExpandMore from "@material-ui/icons/ExpandMore";
import Subject from "./Subject";
import AddSubject from "./AddSubject";
import DeleteFeild from "./DeleteFeild";
import axios from "axios";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    flexWrap: "wrap",
    maxWidth: "70vw",
    justifyContent: "center",
  },
  button: {
    marginRight: "5%",
  },
  Item: {
    padding: "0px 0px 0 25px",
  },
}));

function Div(props) {
  const classes = useStyles();
  const [div, setDiv] = useState([]);
  const [addSubject, setAddSubject] = useState(false);
  const [divName, setDivName] = useState("");
  const [deleteDivName,setDeleteDivName]=useState("");
  const [deleteData, setDeleteData] = useState(false);

  useEffect(() => {
    axios
      .get(`/admin/div/${props.name}/${props.sem}`)
      .then((res) => {
        setDiv(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  const handleDeleteOpen = (value) => {
    setDeleteData(true);
    setDeleteDivName(value);
  };
 
  const handleDeleteClose = (value) => {
    if(value){
      axios.post(`/admin/remove-div/`,{
        deptName:props.name,
        semester:props.sem,
        div:deleteDivName
      })
      .then(res=>{
        console.log(res)
      })
      .catch(err=>{
        console.log(err)
      })
    }
    setDeleteData(false);
  };
  const handleClickOpen = (name) => {
    setAddSubject(true);
    setDivName(name);
  };

  const handleClose = () => {
    setAddSubject(false);
  };

  const handleClick = (i) => {
    // console.log(i);
    let updatedList = div.map((item) => {
      if (item.div === div[i].div) {
        return { ...item, isOpen: !item.isOpen };
      }
      return item;
    });
    setDiv(updatedList);
    // console.log(dept[i].isOpen);
  };

  return (
    <List component="div" disablePadding>
      {div.map((item, index) => (
        <div id={index} className={classes.Item}>
          <ListItem>
            <ListItemIcon>
              <SettingsEthernetIcon />
            </ListItemIcon>
            <ListItemText>Div {item.div}</ListItemText>
            <Button className={classes.button} onClick={()=>{handleDeleteOpen(item.div)}}>
              <DeleteIcon color="primary" />
            </Button>

            <Button
              variant="contained"
              color="primary"
              startIcon={<CreateIcon />}
              className={classes.button}
              onClick={() => {
                handleClickOpen(item.div);
              }}>
              Add Subject
            </Button>

            {item.isOpen ? (
              <IconButton onClick={() => handleClick(index)}>
                <ExpandLess />
              </IconButton>
            ) : (
              <IconButton onClick={() => handleClick(index)}>
                <ExpandMore />
              </IconButton>
            )}
          </ListItem>
          <Collapse in={item.isOpen} timeout="auto" unmountOnExit>
            <Subject name={props.name} sem={props.sem} div={item.div} />
          </Collapse>
        </div>
      ))}
      {addSubject && (
        <AddSubject
          handleClickOpen={handleClickOpen}
          handleClose={handleClose}
          open={addSubject}
          deptName={props.name}
          sem={props.sem}
          div={divName}
        />
      )}
      {deleteData && <DeleteFeild open={deleteData} handleDeleteOpen={handleDeleteOpen} handleDeleteClose={handleDeleteClose} />}
    </List>
  );
}

export default Div;
